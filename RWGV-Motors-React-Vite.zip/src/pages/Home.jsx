import { Link } from 'react-router-dom'

export default function Home(){
  return (
    <main>
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <span className="badge">Acesso Premium</span>
            <h1>Descubra o seu próximo carro de luxo com a <span style={{color:'var(--gold-2)'}}>RWGV Motors</span>.</h1>
            <p>Seleção curada de sedans, SUVs e esportivos. Procedência comprovada, histórico transparente e atendimento consultivo do começo ao fim.</p>
            <div style={{display:'flex', gap:12, flexWrap:'wrap'}}>
              <Link className="btn gold" to="/catalogo">Ver Catálogo</Link>
              <Link className="btn" to="/contato">Simular Financiamento</Link>
            </div>
          </div>
          <div className="hero-card">
            <div className="hero-media">
              <img src="https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?q=80&w=1600&auto=format&fit=crop" alt="Showroom RWGV Motors"/>
            </div>
            <div className="hero-specs">
              <div className="item">
                <div className="label">Veículos Inspecionados</div>
                <div className="value">+120 itens</div>
              </div>
              <div className="item">
                <div className="label">Garantia</div>
                <div className="value">12 meses</div>
              </div>
              <div className="item">
                <div className="label">Aprovação de Crédito</div>
                <div className="value">&lt; 2h úteis</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2>Destaques da Semana</h2>
          <p className="lead">Ofertas exclusivas com taxa especial para agosto.</p>
          <div className="grid">
            <div className="card" style={{gridColumn:'span 6'}}>
              <div className="media">
                <img src="https://images.unsplash.com/photo-1559418041-9d80f8298a2f?q=80&w=1600&auto=format&fit=crop" alt="BMW Série 3"/>
              </div>
              <div className="body">
                <div className="title">BMW Série 3 320i M Sport 2023</div>
                <div className="meta"><span>10.500 km</span><span>Gasolina</span><span>184 cv</span></div>
                <div className="price">R$ 269.900</div>
              </div>
            </div>
            <div className="card" style={{gridColumn:'span 6'}}>
              <div className="media">
                <img src="https://images.unsplash.com/photo-1579484043210-2f0e7a1c13ac?q=80&w=1600&auto=format&fit=crop" alt="Audi Q5"/>
              </div>
              <div className="body">
                <div className="title">Audi Q5 Prestige 2022</div>
                <div className="meta"><span>22.000 km</span><span>Gasolina</span><span>249 cv</span></div>
                <div className="price">R$ 289.000</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2>Serviços</h2>
          <p className="lead">Mais do que vender carros, entregamos tranquilidade.</p>
          <div className="grid">
            <div className="card">
              <div className="body">
                <div className="title">Garantia Estendida</div>
                <p>Cobertura nacional e rede de oficinas credenciadas.</p>
              </div>
            </div>
            <div className="card">
              <div className="body">
                <div className="title">Troca com Troco</div>
                <p>Usamos seu carro na negociação com avaliação justa e rápida.</p>
              </div>
            </div>
            <div className="card">
              <div className="body">
                <div className="title">Financiamento Inteligente</div>
                <p>Parcerias com os principais bancos para as melhores taxas.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
